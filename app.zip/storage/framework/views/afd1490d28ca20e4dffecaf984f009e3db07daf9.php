<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/login-page.css">
    <title>Music App</title>
</head>
<body>
    <div class="heder">
        <!-- background-image: url(../Html-css/img/img1.png );
         -->
         <img src="/assets/image/img1.png" alt="" class="img1">
    </div>
    <div class="heder1">
        <img src="/assets/image/img3.png" alt="" class="img3">
    </div>
    <div class="heder2">
        <img src="/assets/image/img2.png" alt="" class="img2">
    </div>
    <div class="heder3">
        <img src="/assets/image/img4.png" alt="" class="img4">
    </div>
    <div class="boder">
        <img src="/assets/image/logo1.png" alt="" class="logo-img">
    </div>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\test2\resources\views/pagems/home-page.blade.php ENDPATH**/ ?>